package company.payment;

import company.Staff;

public interface PayingSystem {

	void renderPayCheck(Staff staff, double salary);
}
