package company.utility.print;

public interface StaffPrinter {

	void print(String message);
}
