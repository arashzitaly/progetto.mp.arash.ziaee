package company.utils.print;

public interface StaffPrinter {

	void print(String message);
}
