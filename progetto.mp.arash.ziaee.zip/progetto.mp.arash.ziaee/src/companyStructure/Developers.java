package companyStructure;

import java.util.ArrayList;
import java.util.Collection;

import company.utils.print.StaffPrinter;

public final class Developers extends Staff {
	
	private Collection<Staff> programmer = new ArrayList<>();
	
	private int level;
	private String primaryLanugage;
	private int yearsOfExperience;

	private Developers(String name, int level, String primaryLanguage, int yearsOfExperience) {
		super(name);
		this.level = level;
		this.primaryLanugage = primaryLanguage;
		this.yearsOfExperience = yearsOfExperience;
	}
	
	// Methods to manage child component
	public void addProgrammer(Staff devs) {
		if(devs != null)
			programmer.add(devs);
	}
	
	public void removeProgrammer(Staff devs) {
		programmer.remove(devs);
	}
	
	// Builder Pattern : TODO

	@Override
	public void join(String group) {
		
	}

	@Override
	public void leave(String group) {
		// TODO Auto-generated method stub

	}

	@Override
	public double calculateSalary() {
		return 0;
	}

	@Override
	public void printMember(StaffPrinter printer) {
		printer.print("Name: " + getName() + ", Language: " + primaryLanugage);
	}

}
