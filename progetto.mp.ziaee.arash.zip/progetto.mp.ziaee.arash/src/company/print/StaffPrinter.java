package company.print;

public interface StaffPrinter {

	void print(String message);
}
